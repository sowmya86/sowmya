<!DOCTYPE html>
<html>
<head>

<script
  src="https://code.jquery.com/jquery-3.4.1.min.js">
</script>
  
<script
  src="https://code.jquery.com/ui/1.12.0/jquery-ui.min.js"
  integrity="sha256-eGE6blurk5sHj+rmkfsGYeKyZx3M4bG+ZlFyA7Kns7E="
  crossorigin="anonymous">
</script>
 
<script type="text/javascript">

  function countrySearch()
  {
    var searchString = prompt("Please enter name or code", "");
    $.ajax({url: "https://restcountries.eu/rest/v1/name/"+searchString, error: 			function(error) {
     var dialogData = "";
    $("<div id='country-search1' title = 'Enter either Country Name or Code only...'><p>"+dialogData+"</p></div>").dialog
           ({
               modal:true,appendTo: "body",
              buttons: {
                'Search': function()
                {
                  $(this).dialog('close');
 				  countrySearch();
                }
              }
            }).dialog("open");
    }})
    
    $.ajax({url: "https://restcountries.eu/rest/v1/name/"+searchString, success: 			function(result){
			console.log(result);
        	if(result.status == undefined)
            {
				var dialogData = "";
					for (i=0;i<result.length;++i)
                    {
						dialogData += "<br/><b>Name:</b>"+result[i].name+"    												<b>Capital</b>:"+result[i].capital;
					}
           $("<div id='country-search1' title = 'Dialog Title goes here...'><p>"+dialogData+"</p></div>").dialog
           ({
               modal:true,appendTo: "body",
              buttons: {
                'Search': function()
                {
                  $(this).dialog('close');
 				  countrySearch();
                }
              }
            }).dialog("open");
        }
    }});
}
countrySearch();
</script>
</head>
<body>
</body>
</html>